﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FOVDetection3D : MonoBehaviour
{
    public Transform player;
    public float maxAngle;
    public float maxRadius;

    private bool isInFov = false;

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, maxRadius);

        //Rotating transfor.forward by maxAngle, multiply by maxRadius to reach end of the circle
        //Creates two vectors that represent the end lines of the FOV
        Vector3 fovLine1 = Quaternion.AngleAxis(maxAngle, transform.up) * transform.forward * maxRadius;
        Vector3 fovLine2 = Quaternion.AngleAxis(-maxAngle, transform.up) * transform.forward * maxRadius;

        Gizmos.color = Color.blue;
        Gizmos.DrawRay(transform.position, fovLine1);
        Gizmos.DrawRay(transform.position, fovLine2);

        //Visualization of ray between player and AI
        if (isInFov) {
            Gizmos.color = Color.green;
        }
        else {
            Gizmos.color = Color.red;
        }
        Gizmos.DrawRay(transform.position, (player.position - transform.position).normalized * maxRadius);

        //Visualization of ray where AI is facing
        Gizmos.color = Color.black;
        Gizmos.DrawRay(transform.position, transform.forward * maxRadius);

    }

    
    //Check if object in circle, then check if angle between black line and red line is smaller than max angle. 
    //Also check if player is behind a wall (can't see through walls)
    public static bool InFOV3D(Transform checkingObject, Transform target, float maxAngle, float maxRadius)
    {
        Collider[] overlaps = new Collider[10];
        //count = number of overlaps
        int count = Physics.OverlapSphereNonAlloc(checkingObject.position, maxRadius, overlaps); //Check every object in radius, passed into overlaps

        for (int i = 0; i < count; i++) {
            if (overlaps[i] != null) {
                if (overlaps[i].transform == target) {
                    Vector3 directionBetween = (target.position - checkingObject.position).normalized;
                    directionBetween.y *= 0; //Height diffrences between objects can change the angle

                    float angle = Vector3.Angle(checkingObject.forward, directionBetween);

                    if (angle <= maxAngle) {
                        //Object is in FOV!

                        Ray ray = new Ray(checkingObject.position, target.position - checkingObject.position);
                        RaycastHit hit;

                        //Check if a wall is blocking the view
                        if (Physics.Raycast(ray, out hit, maxRadius)) {
                            if (hit.transform == target) {
                                return true;
                            }
                        }
                    }
                }
            }
        }


        return false;
    }

    private void Update()
    {
        isInFov = InFOV3D(transform, player, maxAngle, maxRadius);

    }
}
