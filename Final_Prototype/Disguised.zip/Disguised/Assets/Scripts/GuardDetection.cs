﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GuardDetection : MonoBehaviour
{

    int playerLayer;						//The layer the player game object is on

    void Start()
    {
        //Get the integer representation of the "Player" layer
        playerLayer = LayerMask.NameToLayer("Player");
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        //If the collided object isn't on the Player layer, exit. This is more 
        //efficient than string comparisons using Tags
        if (collision.gameObject.layer != playerLayer)
            return;

        //Tell the game manager that guard detected player
        //GameManager.PlayerGrabbedOrb(this);

        //Deactivate this guard to hide it and prevent further collection
        gameObject.SetActive(false);
    }
}
