﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Patrol : MonoBehaviour
{
    private const int ANIM_STATE_IDLE = 0;
    private const int ANIM_STATE_WALKING = 1;
    private const int ANIM_STATE_ATTACK = 2;
    public Transform[] patrolPoints;
    public float speed;
    public float distance;
    int currentPoint;

    int walkParamID;			//ID of the speed parameter

    //Animator anim;
    //SpriteRenderer sprite;

    // Use this for initialization
    void Start()
    {
        
        //Get the integer hashes of the parameters. This is much more efficient
        //than passing strings into the animator
        walkParamID = Animator.StringToHash("isWalking");

        //Grab a reference to this object's parent transform
        //Transform parent = transform.parent;

        //anim = GetComponent<Animator>();

        StartCoroutine("GuardPatrol");
    }

    // Update is called once per frame
    void Update()
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, transform.localScale.x * Vector3.left, distance);//needed to check in front of him got any object

        if (hit.collider != null && hit.collider.tag == "Player") {
            //anim.SetInteger("state", ANIM_STATE_ATTACK);
            StopCoroutine("GuardPatrol");
        }

    }

    IEnumerator GuardPatrol()
    {
        while (true) {    //this is to make sure this method is infinite loop
            if (this.transform.position.x == patrolPoints[currentPoint].position.x) {
                currentPoint++;

                //anim.SetBool(walkParamID, false);
                //anim.SetInteger("state", ANIM_STATE_IDLE);
                yield return new WaitForSeconds(2);    //once it rech the point, stop for a while 1st
                transform.RotateAround(transform.position, transform.up, 180f);
                //anim.SetInteger("state", ANIM_STATE_WALKING);
                //anim.SetBool(walkParamID, true);

            }

            if (currentPoint >= patrolPoints.Length) {

                currentPoint = 0;    //reset it to zero
            }


            //this.transform.position = Vector2.MoveTowards(this.transform.position, new Vector2(patrolPoints[currentPoint].position.x, transform.position.y), speed);
            this.transform.position = Vector3.MoveTowards(this.transform.position, new Vector3(patrolPoints[currentPoint].position.x, transform.position.y, transform.position.z), speed);


            if (transform.position.x > patrolPoints[currentPoint].position.x) {
                //sprite.flipX = true;
                //transform.localScale = new Vector3 (1,1,1);    //either 1 of this method will change the rotation of the object

            }
            else if (transform.position.x < patrolPoints[currentPoint].position.x) {
                //sprite.flipX = false;
                //transform.localScale = new Vector3 (-1,1,1);

            }

            yield return null;    //this will tells this method to execute the above code again once next frame started
        }
    }

    void OnTriggerEnter2D(Collider2D coll)
    {


    }

    void OnDrawGizmos()
    {
        Gizmos.color = Color.cyan;    //for visual debugging purpose
        Gizmos.DrawLine(transform.position, transform.position + transform.localScale.x * Vector3.left * distance);
    }
}
