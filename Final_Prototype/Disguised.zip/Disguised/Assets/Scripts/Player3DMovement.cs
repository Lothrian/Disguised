﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PlayerController : MonoBehaviour {

    #region Variables
    [Header("Player Options")]
    public float playerHeight;

    [Header("Movement Options")]
    public float movementSpeed;
    public bool smooth;
    public float smoothSpeed;

    [Header("Jump Options")]
    public float jumpForce;
    public float jumpSpeed;
    public float jumpDecrease;
    public float incrementJumpFallSpeed = 0.1f;

    [Header("Gravity")]
    public float gravity = 2.5f;

    [Header("Physics")]
    public LayerMask discludePlayer;

    [Header("References")]
    public SphereCollider sphereCol;

    //Movement vectors
    private Vector3 velocity;
    private Vector3 move;
    private Vector3 vel;

    #endregion

    #region Main Methods
    private void Update() {
        Gravity();
        simpleMove();
        Jump();
        finalMove();
        groundChecking();
        collisionCheck();
    }

    #endregion

    #region Movement Methods
    private void simpleMove() {
        move = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical")); //Move in 2 directions
        //move = new Vector3(Input.GetAxis("Horizontal"), 0, 0); move in 3 directions
        velocity += move;
    }

    private void finalMove() {
        Vector3 vel = new Vector3(velocity.x, velocity.y, velocity.z) * movementSpeed;
        //velocity = (new Vector3(move.x, -currentGravity + jumpHeight, move.z) + vel)* movementSpeed;
        //velocity = transform.TransformDirection(velocity);
        vel = transform.TransformDirection(vel);
        transform.position += vel * Time.deltaTime;

        velocity = Vector3.zero;
    }

    #endregion

    #region Gravity/Grounding
    //Gravity private variables
    private bool grounded;
    private float currentGravity = 0;

    //Grounded private variables
    private Vector3 liftPoint = new Vector3(0, 1.2f, 0);
    private RaycastHit groundHit;
    private Vector3 groundCheckpoint = new Vector3(0, -0.87f, 0);

    private void Gravity() {
        if (grounded == false) {
            velocity.y -= gravity;
        }
        else {
            currentGravity = 0;
        }
    }

    private void groundChecking() {
        Ray ray = new Ray(transform.TransformPoint(liftPoint), Vector3.down);
        RaycastHit tempHit = new RaycastHit();

        if(Physics.SphereCast(ray, 0.17f, out tempHit, 20, discludePlayer)) {
            groundConfirm(tempHit);
        }
        else {
            grounded = false;
        }
    }

    private void groundConfirm(RaycastHit tempHit) {
        //float currentSlope = Vector3.Angle(tempHit.normal, Vector3.up);
        Collider[] col = new Collider[3];
        int num = Physics.OverlapSphereNonAlloc(transform.TransformPoint(groundCheckpoint), 0.57f, col, discludePlayer);

        grounded = false;

        for(int i = 0; i < num; i++) {
            if (col[i].transform == tempHit.transform) {
                groundHit = tempHit;
                grounded = true;

                if(inputJump == false) { 
                    //Snap player to the ground
                    if (!smooth) {
                        transform.position = new Vector3(transform.position.x, (groundHit.point.y + playerHeight / 2), transform.position.z);
                    }
                    else {
                        //Linear Interpolation
                        transform.position = Vector3.Lerp(transform.position, new Vector3(transform.position.x, (groundHit.point.y + playerHeight / 2), transform.position.z), smoothSpeed * Time.deltaTime);
                    }
                }

                break;
            }
        }

        //Check if against wall if not jumping
        if(num <= 1 && tempHit.distance <= 3.1f && inputJump == false) {
            if(col[0] != null) {
                Ray ray = new Ray(transform.TransformPoint(liftPoint), Vector3.down);
                RaycastHit hit;

                if(Physics.Raycast(ray, out hit, 3.1f, discludePlayer)) {
                    if(hit.transform != col[0].transform) {
                        grounded = false;
                        return;
                    }
                }
            }
        }

        //grounded = true;

    }
    #endregion

    #region Collision
    private void collisionCheck() {
        Collider[] overlaps = new Collider[4];
        int num = Physics.OverlapSphereNonAlloc(transform.TransformPoint(sphereCol.center), sphereCol.radius, overlaps, discludePlayer, QueryTriggerInteraction.UseGlobal);

        for(int i = 0; i < num; i++) {
            Transform t = overlaps[i].transform;
            Vector3 dir;
            float dist;

            // Gets current velocity and direction penetration inversed, project velocity onto direction
            if(Physics.ComputePenetration(sphereCol, transform.position, transform.rotation, overlaps[i], t.position, t.rotation, out dir, out dist)){
                Vector3 penetrationVector = dir * dist;
                Vector3 velocityProjected = Vector3.Project(velocity, -dir);
                transform.position = transform.position + penetrationVector;
                vel -= velocityProjected;
            }
        }
    }

    #endregion

    #region Jumping

    private float jumpHeight = 0;
    private bool inputJump = false;

    private float fallMultiplier = -1;

    private void Jump() {
        bool canJump = false;

        //Physics.Raycast returns a boolean
        canJump = !Physics.Raycast(new Ray(transform.position, Vector3.up), playerHeight, discludePlayer);

        //If grounded, make sure jump height is 0. stop jumping once grounded
        if(grounded && jumpHeight > 0.2f || jumpHeight <= 0.2f && grounded) {
            jumpHeight = 0;
            inputJump = false;
            fallMultiplier = -1;
        }

        if(grounded && canJump) {
            if (Input.GetKeyDown(KeyCode.Space)) {
                inputJump = true;
                transform.position += Vector3.up * 0.6f;
                jumpHeight += jumpForce;
            }
        }
        else {
            if (!grounded) {
                jumpHeight -= (jumpHeight * jumpDecrease * Time.deltaTime) + fallMultiplier * Time.deltaTime;
                fallMultiplier += incrementJumpFallSpeed; //increase fall multiplier every frame player is in the air
            }
        }

        velocity.y += jumpHeight;
    }

    #endregion
}
