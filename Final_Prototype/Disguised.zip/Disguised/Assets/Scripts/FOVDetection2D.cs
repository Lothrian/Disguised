﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FOVDetection2D : MonoBehaviour
{
    public Transform playerTarget;

    void Update()
    {
        Vector3 targetDir = playerTarget.position - transform.position;
        Vector3 forward = transform.forward;
        float angle = Vector3.Angle(targetDir, forward);
        if (angle < 5.0F)
            Debug.Log("close");
        else {
            Debug.Log(angle);
        }

    }
}
