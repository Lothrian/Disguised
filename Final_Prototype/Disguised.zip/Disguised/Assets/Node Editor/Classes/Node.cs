﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class Node : MonoBehaviour{

    public Rect pos = new Rect(new Vector2(100, 100), new Vector2(100, 100));
    public string name;

    public void DrawNode() {
        //Every time we called DrawNode, a new box will be drawn at pos
        DrawBox();

    }

    private void DrawBox() {
        GUI.Box(pos, name);
    }

    public Node(string name) {
        this.name = name;
    }
}
